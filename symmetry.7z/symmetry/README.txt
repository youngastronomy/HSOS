﻿
按 E:\Software\autopress\小磁场扫描位置图.bmp  放好程序位置。注意调波带程序在任务栏上必须放在最左边。

auto_scan_measurement.pro    自动扫描波带测量Q,U,V
auto_scan.pro		自动扫描波带测量，每天早晨测量磁场前运行，也可以在需要的时候运行.
symmetry_period.pro		周期性执行磁场测量,可设置间隔时间(s)，一般取1800s
symmetry_routine.pro		单次执行磁场测量，在谱线对称位置±0.075测量stokes参数。设置lucky=1,程序就完全自动采集。如果需要判断数据的质量，并输入y 
			                  or n让自动程序是否继续进行。并输入y（满意，不需要重新观测） or n（不满意，让程序重新观测）
obs_new.pro		查看测量结果。


auto_scan_measurement.pro, auto_scan.pro,symmetry_period.pro 可以设置曝光时间和叠加帧数.

测量完成后。原始测量得到的磁场文件存在工作路径下：如：E:\Mag\2017\05\27
矫正之后的Q,U,L数据在calibration文件夹下。


生成的txt文件的解释：

couple.txt  配对的红翼和蓝翼原始磁场数据文件名，  L0 L1 Q0 Q1 U0 U1 0为蓝翼 1为红翼
lincen.txt   扫波带时得到第一个文件和线心位置
seq.txt      测量的顺序LR：蓝翼到红翼（左到右） RL:红翼到蓝翼（右到左）。如果测量时不0扫描波带，
                使用现有线心数据需要将此文件删除后，运行symmetry_routine.pro
             
             
在自动测量时请勿动鼠标和键盘，如遇到问题，请停止调试然后重新点击程序运行。
